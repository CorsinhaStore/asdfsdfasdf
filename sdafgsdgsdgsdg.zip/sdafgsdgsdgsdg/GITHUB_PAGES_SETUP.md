# Como hospedar no GitHub Pages

## Passos para configurar:

### 1. Faça upload do código para o GitHub
- Crie um repositório novo no GitHub
- Faça push de todo o código para o repositório

### 2. Configure GitHub Pages no repositório
- Vá para Settings > Pages no seu repositório
- Em "Source", selecione "GitHub Actions"
- O workflow já está configurado em `.github/workflows/deploy.yml`

### 3. Ative o workflow
- Faça um commit e push para a branch `main` ou `master`
- O GitHub Actions automaticamente fará o build e deploy
- Seu site ficará disponível em: `https://seuusuario.github.io/nome-do-repositorio`

## Scripts disponíveis:

- `npm run build:static` - Gera build apenas para frontend (para GitHub Pages)
- `npm run build` - Build completo com backend (para Replit/outros servidores)
- `npm run dev` - Execução local com backend

## Nota importante:
O GitHub Pages hospeda apenas o frontend (site estático). As funcionalidades que dependem do backend (login, banco de dados) mostrarão avisos informativos no modo estático.

✅ **Melhorias implementadas para GitHub Pages:**
- SPA routing funcionando (404.html criado automaticamente)
- Avisos amigáveis quando funcionalidades backend não estão disponíveis
- Build otimizado para sites estáticos
- Deploy automático via GitHub Actions

Para ter funcionalidades completas, use:
- Replit (full-stack)
- Vercel, Netlify (frontend) + backend separado
- Ou outros serviços que suportam Node.js

## Estrutura de arquivos GitHub Pages:
```
.github/workflows/deploy.yml    # Workflow automático do GitHub Actions
vite.config.static.ts          # Configuração Vite para build estático
dist/public/                   # Arquivos gerados para GitHub Pages
```