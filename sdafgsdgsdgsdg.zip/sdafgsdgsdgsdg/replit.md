# Corsinha Store - E-commerce Admin Panel

## Overview

Corsinha Store is a comprehensive e-commerce admin panel system built with React, TypeScript, and Express.js. The application provides a complete solution for managing products, categories, and store operations through a modern, responsive interface. The system features a secure admin-only authentication system with a single authorized user (corsinhastore@gmail.com) and supports full CRUD operations for product and category management.

The application follows a clean architecture pattern with separated concerns between frontend components, backend API routes, and data management. It includes a customer-facing store view alongside the administrative interface, providing a complete e-commerce solution.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern component patterns
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible interfaces
- **Styling**: Tailwind CSS with custom design system featuring black/red color scheme
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Routing**: File-based component organization with programmatic navigation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Express sessions with bcrypt password hashing and rate limiting
- **Session Storage**: Connect-pg-simple for PostgreSQL-backed session persistence
- **Security**: CSRF protection, secure cookies, and brute force prevention

### Database Schema
- **Users Table**: Admin authentication with hashed passwords
- **Categories Table**: Product categorization with timestamps
- **Products Table**: Complete product information including images, pricing, purchase links, and terms
- **Relationships**: Products reference categories through foreign keys

### Component Architecture
- **Layout System**: Sidebar-based admin layout with responsive design
- **Product Management**: Full CRUD interface with image upload, category assignment, and terms management
- **Store View**: Customer-facing product display with search, filtering, and purchase integration
- **Authentication Flow**: Secure login with session management and auto-logout

### Design System
- **Color Palette**: Black (0 0% 8%) backgrounds, Red (0 85% 45%) accents, White (0 0% 98%) content
- **Typography**: Inter font family with consistent weight and sizing scale
- **Layout Grid**: 4-column responsive product grid (2-col mobile, 3-col tablet)
- **Component Patterns**: Card-based layouts with consistent spacing and hover states

## External Dependencies

### Database Infrastructure
- **PostgreSQL**: Primary database for data persistence
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle ORM**: Type-safe database queries and migrations

### UI and Styling
- **Radix UI**: Accessible component primitives for dialogs, dropdowns, and form controls
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **Google Fonts**: Inter font family loaded via CDN
- **Lucide React**: Icon library for consistent iconography

### Authentication and Security
- **bcrypt**: Password hashing and validation
- **express-session**: Session management middleware
- **express-rate-limit**: Brute force protection for authentication endpoints
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **Vite**: Fast development server and build tool with HMR
- **TypeScript**: Static type checking and enhanced development experience
- **ESBuild**: Fast bundling for production builds
- **Replit Integration**: Development environment integration and deployment

### Third-party Integrations
- **WhatsApp Business**: Purchase link integration for customer communication
- **Image Hosting**: External image URLs for product galleries
- **Payment Systems**: Configurable external payment links (PIX, other platforms)