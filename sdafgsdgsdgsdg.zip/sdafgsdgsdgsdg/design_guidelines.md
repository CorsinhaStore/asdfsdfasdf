# E-commerce Admin Panel Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern e-commerce platforms like Shopify Admin and Notion's clean interface, focusing on professional utility while maintaining visual appeal for the customer-facing store.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Black: 0 0% 8% (main backgrounds, text)
- Red: 0 85% 45% (primary actions, alerts, branding)
- White: 0 0% 98% (text on dark, cards)

**Supporting Colors:**
- Gray variants: 0 0% 20%, 0 0% 35%, 0 0% 65% (borders, secondary text, disabled states)
- Success green: 120 60% 40% (confirmations)
- Warning amber: 45 90% 55% (cautions)

### Typography
**Font Family:** Inter via Google Fonts CDN
- Headings: 600-700 weight, sizes from text-lg to text-3xl
- Body text: 400-500 weight, text-sm to text-base
- Buttons/Labels: 500 weight, text-sm

### Layout System
**Spacing Units:** Consistent use of Tailwind units 2, 4, 6, 8, 12, 16
- Tight spacing: p-2, m-2 (buttons, small components)
- Standard spacing: p-4, gap-4 (cards, form fields)
- Section spacing: p-8, mb-12 (page sections, major components)

### Component Library

**Admin Panel Components:**
- **Navigation:** Dark sidebar with red accent highlights for active states
- **Data Tables:** Clean white cards with subtle gray borders, red action buttons
- **Forms:** Standard input fields with red focus states, validation messaging
- **Modals:** Centered overlays with backdrop blur, consistent with color scheme

**Customer Store Components:**
- **Product Grid:** 4-column responsive layout (mobile: 2-col, tablet: 3-col)
- **Product Cards:** White cards with subtle shadows, red "Buy Now" buttons
- **Search Bar:** Prominent placement with red accent on focus
- **Category Filters:** Horizontal pill-style buttons with red active states

### Specific Design Requirements

**Loading Screen:** Full-screen black background with animated red loading indicator

**Admin Authentication:** Minimalist login form on black background, red submit button

**Product Management:** 
- Image upload areas with drag-drop styling
- Multi-image gallery with thumbnail previews
- Rich text editor for descriptions with standard formatting toolbar

**Code Editor Panel:** Dark theme editor (Monaco/CodeMirror style) integrated into admin interface

**Terms Popup:** Modal overlay with scrollable content, consistent typography hierarchy

### Visual Hierarchy
- Use red sparingly for primary actions and brand moments
- Maintain high contrast between text and backgrounds
- Employ generous whitespace in admin panels for clarity
- Customer store should feel more inviting with softer shadows and rounded corners

### Responsive Behavior
- Mobile-first approach with touch-friendly button sizes (min 44px)
- Collapsible admin sidebar on mobile
- Stacked form layouts on smaller screens
- Product grid adapts from 4-col to 2-col to 1-col based on viewport

### Images
**Admin Panel:** No large hero images - focus on functional interface with product thumbnails and user-uploaded content

**Customer Store:** Optional header banner area for promotional content, product images as primary visual elements in grid layout

This design balances professional admin functionality with an appealing customer shopping experience, using the black and red theme to create brand consistency across both interfaces.